1) ¿Para qué sirve el archivo package.json?

Es el archivo de configuración del proyecto que sirve para guardar datos (eg: nombre y lista de dependencias que usa el proyecto + los scripts disponibles), esto significa que la capreta de node modules no hace falta porque ya están las dependencias dentro del archivo, entonces la carpeta de modules se puede reconstruir todas las veces que sea necesario leyendo "package.json." 


2) ¿Qué diferencia notamos entre ejecutar un archivo con Node.js y levantar el servidor de React?

cuando se corre node app.js se ejecuta el archivo una unica vez mientras que con npm run dev se levanta un Vite (servidor) que queda corriendo (y se tiene que parar)