import { useState } from 'react'
import './App.css'

function App() {
  // Estado: guarda cuántas veces se hizo clic en el botón
  const [contador, setContador] = useState(0)

  return (
    <main className="app">
      <h1>Hola Mundo desde React - P3</h1>

      <section className="contador">
        <p className="valor">{contador}</p>
        <p className="texto">
          {contador === 1 ? 'clic' : 'clics'} hasta ahora
        </p>

        <div className="botones">
          <button onClick={() => setContador(contador + 1)}>
            Sumar
          </button>
          <button className="reset" onClick={() => setContador(0)}>
            Reiniciar
          </button>
        </div>
      </section>

      <footer>
        Mini-app interactiva con <code>useState</code> · Programación III
      </footer>
    </main>
  )
}

export default App
